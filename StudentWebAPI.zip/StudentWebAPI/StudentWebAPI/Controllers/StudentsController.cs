﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using StudentWebAPI.Models;

namespace StudentWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentsController : ControllerBase
    {
        IStudentDetails m_studentDetails;
        public StudentsController(IStudentDetails studentDetails)
        {
            m_studentDetails = studentDetails;  
        }
        [EnableCors("MyAllowSpecificOrigins")]
        [HttpGet]
        public IEnumerable<Student> Get() 
        {
            return m_studentDetails.GetStudent();
        }
    }
}

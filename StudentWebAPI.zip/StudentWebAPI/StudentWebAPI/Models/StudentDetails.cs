﻿namespace StudentWebAPI.Models
{
    public interface IStudentDetails
    {
        public List<Student> GetStudent();
    }
    public class StudentDetails : IStudentDetails
    {
        public List<Student> GetStudent()
        {
            var students = new List<Student>()
            {
                new Student()
                {
                    Id = 1,
                    Name = "Varun",
                    age = 10
                },
                new Student()
                {
                    Id = 2,
                    Name = "Tarun",
                    age = 12

                },
                new Student()
                {
                    Id = 3,
                    Name = "Teena",
                    age = 13
                },
                new Student()
                {
                    Id = 4,
                    Name = "Meena",
                    age = 14
                },
                new Student() 
                {
                    Id = 5, 
                    Name="Reena",
                    age = 15   
                },
                new Student() 
                {
                    Id = 6, 
                    Name="Anisha",
                    age = 16  
                },
                new Student()
                {
                    Id= 7,  
                    Name="Tanisha",
                    age = 17    
                },
                new Student()
                {
                    Id=8,
                    Name="Manisha",
                    age= 18 
                },
                new Student()
                {
                    Id=9,
                    Name="Esha",
                    age= 19 
                },
                new Student()
                {
                    Id=10,
                    Name="Sarthak",
                    age= 20 
                }

            };
            return students;
        }
    }
}
